#include "Generations.h"
// Constructora
Generations::Generations(int gen_) : numGen(gen_) {}
// Destructora
Generations::~Generations() {}
// Inicializa el componente
void Generations::initComponent() {}